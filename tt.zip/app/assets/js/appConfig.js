const filterConsoleErrors = () => {
    const consoleError = console.error;

    if (window && window.console) {
        window.console.error = (...args) => {
            if (typeof args[0] === 'string') {
                if (args[0].indexOf('React Intl') > -1) {
                    return;
                }
                if (args[0].indexOf('Warning') > -1) {
                    return;
                }

                consoleError(args[0]);
                return;
            }

            consoleError(...args);
        };
    }
};
filterConsoleErrors();
/* eslint-disable no-unused-vars */
const BASE = 'https://g.lifetek.vn:201';
const UPLOAD_APP = 'https://g.lifetek.vn:203/api';
// Pall start
// const CLIENT = '60_CRM';
// const APP = 'https://g.lifetek.vn:260';
// Pall end
const UPLOAD_AI = 'https://g.lifetek.vn:225';
// Staging start
const CLIENT = 'x06dev';
const APP = 'https://g.lifetek.vn:259';
const APP_REPORT = 'https://g.lifetek.vn:254';
// const APP = 'http://172.16.10.13:10020';
// Staging end

// Internal start
// const CLIENT = '80_LIFETEK';
// const APP = 'https://g.lifetek.vn:280';
// Internal end

// Local start
// const CLIENT = 'APP_CRM';
//   const APP = 'http://localhost:10020';
// Local end

const DYNAMIC_FORM = 'https://g.lifetek.vn:219';
const AUTOMATION = 'https://g.lifetek.vn:208';
const PROPERTIES_APP = 'https://g.lifetek.vn:207/api';
const APPROVE = 'https://g.lifetek.vn:210';
const ALLOW_FILE_EXT = ['.pdf', '.txt', '.docx', '.doc', '.xls', '.xlsx', '.csv', '.jpeg', '.jpg', '.png'];

// const APP = 'http://localhost:10020';
// const BASE = 'http://localhost:10201';
// const AUTOMATION = 'http://localhost:10208';
// const BASE = 'http://admin.lifetek.vn:1000';
// const UPLOAD_APP = 'http://admin.lifetek.vn:1003/api';
// const CLIENT = '2077App';
// const APP = 'http://admin.lifetek.vn:2077';
// const DYNAMIC_FORM = 'http://admin.lifetek.vn:1019';
// const AUTOMATION = 'http://admin.lifetek.vn:1008';
// const PROPERTIES_APP = 'http://admin.lifetek.vn:1007/api';
// const APPROVE = 'http://admin.lifetek.vn:1010';

// const BASE = 'http://admin.lifetek.vn:1000';
// const UPLOAD_APP = 'http://admin.lifetek.vn:1003/api';
// const CLIENT = '2090App';
// const APP = 'http://admin.lifetek.vn:2090';
// const DYNAMIC_FORM = 'http://admin.lifetek.vn:1019';
// const AUTOMATION = 'http://admin.lifetek.vn:1008';
// const PROPERTIES_APP = 'http://admin.lifetek.vn:1007/api';
// const APPROVE = 'http://admin.lifetek.vn:1010';

const NAME_LOCATION = 'CÔNG AN THÀNH PHỐ HÀ NỘI - BỘ CÔNG AN';
const USER_AFK_TIME = 15 * 60 * 1000;
const ENABLE_SSO = false;
const SSO_HOST = 'https://172.16.0.20/service/soap';
const POTAL = 'https://g.lifetek.vn:8080/vi/web/qlh05';
const EMAIL = 'https://g.lifetek.vn:500/h/search?mesg=welcome&init=true';
const FILE_SIZE = 1000 * 1000 * 1000 * 8 * 5
const SPEECH2TEXT = 'https://g.lifetek.vn:227';
const API_SMART_FORM = 'https://g.lifetek.vn:3001';
const API_JSON_FILE ='https://g.lifetek.vn:259'
const API_JSON_IMPORT ='https://g.lifetek.vn:259'
const ID_FILE_SAMPLE ='64545ad88af84c0fd07c6217'
const FILE_SAME_PCDB ='https://g.lifetek.vn:203/api/files/64576930d33c104b10998b34'


const INSERT_SOVANBAN = {
    A4: {
        "x": 150,
        "y": 130,
        // "content": "already broken",
        'fontSize': 16,

    }
}
// 'company: cục', 'department: phòng', 'stock', 'factory', 'workshop', 'salePoint: đội', 'corporation'
const DASHBOARD_TREE_SETTINGS = [
    {
        ROLE: ['CUCTRUONG', 'CUCPHO', 'GIAMDOC', 'PHOGIAMDOC'],
        UNITS: ['company', 'department']
    },
    {
        ROLE: ['TRUONGPHONG', 'PHOTRUONGPHONG'],
        UNITS: ['department', 'salePoint']
    },
    {
        ROLE: ['DOITRUONG', 'DOIPHO', 'CANBO'],
        UNITS: ['salePoint']
    }
]
const MIN_ORDER_SHOW_IN_LIST = 3.5
const orderCanHidden = 2
const ISPORTAL = false
const CODE_SEND_ANY = ['GIAMDOC', 'TRUONGPHONG']

const CHOOSE_APP_HOST = 'https://x06dev.lifetek.vn/'
const MODULE =  "X06_Letter"
const LIST_STAGE =  [
    { title: 'Tiếp nhận', value: 'receive' },
    { title: 'Xử lý', value: 'process' },
    { title: 'Phê duyệt cấp phòng', value: 'approveRoom' },
    { title: 'Phê duyệt', value: 'approve' },
  ];

  const LIST_FUNCTION = [
    {
        title: 'Chọn xử lý',
        value: 'send'
    },
    {
        title: 'Trả lại',
        value: 'pay'
    },
    {
        title: 'Trình lãnh đạo phòng',
        value: 'sendLeaderRoom'
    },
    {
        title: 'Từ chối',
        value: 'refuse'
    },
    {
        title: 'Đề xuất',
        value: 'propose'
    },
    {
        title: 'Phê duyệt',
        value: 'approve'
    }
];



const LIST_FEATURE = [
    {
        title: 'giám đốc 1',
        value: 'receiver'
    },
    {
        title: 'giám đốc 2',
        value: 'processing'
    },
    // {
    //     title: 'Trình duyệt',
    //     value: 'processing'
    // },
    {
        title: 'giám đốc 3',
        value: 'approve'
    },
    {
        title: 'giám đốc 4',
        value: 'complete'
    }
];

const LIST_GIVE_BACK = [
    {
        title: 'Tiếp nhận',
        value: 'receiver'
    },
    {
        title: 'Xử lý',
        value: 'processing'
    },
    // {
    //     title: 'Trình duyệt',
    //     value: 'processing'
    // },
    {
        title: 'Phê duyệt',
        value: 'approve'
    },
    {
        title: 'Hoàn thành',
        value: 'complete'
    }
];


const LIST_REFUSE = [
    {
        title: 'Tiếp nhận',
        value: 'receiver'
    },
    {
        title: 'Xử lý',
        value: 'processing'
    },
    // {
    //     title: 'Trình duyệt',
    //     value: 'processing'
    // },
    {
        title: 'Phê duyệt',
        value: 'approve'
    },
    {
        title: 'Hoàn thành',
        value: 'complete'
    }
];


const LIST_ROLE_CB = ['Truongphong', 'Photruongphong', 'CANBO']
const TRUONG_PHONG = 'Truongphong'
const phochunhiemUB = 'PhochunhiemUB'
const phochunhiemTT = 'PhochunhiemTT'
const uyvien = 'Uyvien'
const vanthu = 'VANTHU'
