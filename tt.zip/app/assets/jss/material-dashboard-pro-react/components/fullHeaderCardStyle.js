// ##############################
// // // RegularCard styles
// #############################

import {
  card,
  cardHeader,
  defaultFont,
  orangeCardHeader,
  greenCardHeader,
  redCardHeader,
  blueCardHeader,
  purpleCardHeader,
  roseCardHeader,
} from 'assets/jss/material-dashboard-pro-react';

const fullHeaderCardStyle = {
  card,
  cardPlain: {
    background: 'transparent',
    boxShadow: 'none',
  },
  cardHeader: {
    ...cardHeader,
    ...defaultFont,
  },
  cardPlainHeader: {
    marginLeft: 0,
    marginRight: 0,
  },
  orangeCardHeader,
  greenCardHeader,
  redCardHeader,
  blueCardHeader,
  purpleCardHeader,
  roseCardHeader,
  cardTitle: {
    color: '#FFFFFF',
    marginTop: '0',
    marginBottom: '5px',
    ...defaultFont,
    fontSize: '1.125em',
  },
  cardSubtitle: {},
  cardActions: {
    padding: '14px',
    display: 'block',
    height: 'auto',
  },
  cardContent: {
    padding: '15px 20px',
    position: 'relative',
  },
};

export default fullHeaderCardStyle;
