import React, { useRef, useState } from 'react';
import { API_INCOMMING_DOCUMENT } from 'config/urlConfig';
import { TextField, Dialog as DialogUI, AsyncAutocomplete } from 'components/LifetekUi';
import DepartmentSelect from '../DepartmentSelect/ForDocument';
import CustomInputBase from 'components/Input/CustomInputBase';
import request from '../../utils/request';
import FeedBackDocument from '../DepartmentSelect/FeedBackDocument';

const columnSettings = [
  {
    name: 'commanders',
    title: 'Xin ý kiến',
    _id: '5fb3ad613918a44b3053f080',
  },
];
const DocumentAssignModal = props => {
  const { open, docIds, onChangeSnackbar, template, currentRole, isAuthory = false, roleGroupSource, consult, profile, info } = props;
  const [allowedOrgs, setAllowedOrgs] = useState([]);
  const [allowedUsers, setAllowedUsers] = useState([]);
  const [note, setNote] = useState(null);
  const [result, setResult] = useState({});
  const [disableSave, setDisableSave] = useState(false);
  const [replyUser, setReplyUser] = useState();
  React.useEffect(
    () => {
      setDisableSave(false);
    },
    [open],
  );
  return (
    <DialogUI
      title="Xin ý kiến"
      disableSave={!result || !result.commandersUsers  || !(result && result.commandersUsers && result.commandersUsers.length)|| !docIds || !docIds.length || disableSave}
      onSave={() => {
        setDisableSave(true);
        const url = isAuthory ? `${API_INCOMMING_DOCUMENT}/set-commanders?authority=true` : `${API_INCOMMING_DOCUMENT}/set-commanders`;
        const body = {
          docIds,
          commanders: result.commandersUsers,
          note,
          replyUser,
          proposer: profile && profile._id,
        };
        request(url, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        })
          .then(res => {
            setDisableSave(true);
            onChangeSnackbar({ variant: 'success', message: 'Xin ý kiến thành công', status: true });
            if (props.onSuccess) {
              return props.onSuccess();
            }
            props.onClose && props.onClose();
          })
          .catch(error => {
            setDisableSave(false);
            onChangeSnackbar({ variant: 'success', message: 'Xin ý kiến thất bại', status: false });
          });
      }}
      saveText="Gửi"
      onClose={() => props.onClose && props.onClose()}
      open={open}
      style={{ position: 'relative' }}
    >
      {/* <DepartmentSelect
        title=""
        allowedDepartmentIds={allowedOrgs}
        allowedUsers={allowedUsers}
        onChange={value => {
          // setAllowedOrgs(value);
        }}
        columnSettings={columnSettings}
        onAllowedUsersChange={value => {
          // setAllowedUsers(value);
        }}
        onChangeColumnCheck={(result) => {
          setResult(result);
        }}
        firstColumnStyle={{
          width: 300
        }}

        currentRole={currentRole ? currentRole : (template && template.group && template.group[0]) ? template.group[0].person : ''}
        template={template}
      /> */}
      
      <FeedBackDocument
        title=""
        allowedDepartmentIds={allowedOrgs}
        allowedUsers={allowedUsers}
        onChange={value => {
          // setAllowedOrgs(value);
        }}
        columnSettings={columnSettings}
        onAllowedUsersChange={value => {
          // setAllowedUsers(value);
        }}
        onChangeColumnCheck={result => {
          setResult(result);
          setReplyUser(result && result.commandersUsers);
        }}
        firstColumnStyle={{
          width: 300,
        }}
        currentRole={currentRole ? currentRole : template && template.group && template.group[0] ? template.group[0].person : ''}
        template={template}
        roleGroupSource={roleGroupSource}
        profile={props.profile}
        typePage={props.typePage}
        typepage={props.typepage || props.processType}
        docIds={docIds}
        consult={consult}
        infor={info}
      />
      {
        console.log(info, 'info')
      }
      <CustomInputBase
        multiline
        rows={2}
        value={note}
        name="note"
        // showSpeaker
        onChange={e => setNote(e.target.value)}
        label="Nội dung xin ý kiến"
        checkedShowForm
        // error={!note}
        // helperText={!note ? 'Đồng chí chưa nhập nội dung xin ý kiến' : ''}
      />
    </DialogUI>
  );
};

export default DocumentAssignModal;
