import {
  Checkbox, Grid, TextField
} from '@material-ui/core';
import { AccountBalance, AccountCircle, ExpandLess, ExpandMore, Search } from '@material-ui/icons';
import _ from 'lodash';
import React, { useEffect, useState } from 'react';
import { API_INCOMMING_DOCUMENT, API_ORIGANIZATION, API_ROLE_APP, MIN_ORDER } from '../../config/urlConfig';
import { convertDot, fetchData, flatChildOpen } from '../../helper';
import { serialize } from '../../utils/common';
import './index.css';
const TextFieldUI = props => <TextField id="id" {...props} />;
TextFieldUI.defaultProps = {
  size: 'small',
};
// document.getElementById('id').style.borderRadius = '10px'
let roleGroupsOrder = {};
try {
  roleGroupsOrder = JSON.parse(localStorage.getItem('roleGroups'));
} catch (error) {
}
let dataProcess = []
let roleSupportAll = []

function DepartmentSelect(props) {
  const {
    onChange,
    title,
    allowedDepartmentIds,
    allowedUsers = [],
    onAllowedUsersChange,
    isMultiple,
    targetGroupCode,
    onChangetargetGroupCode,
    disabledEmployee,
    onChangeAddRoles,
    typeReturn,
    columnSettings,
    type = '',
    typeFlow = '',
    onChangeColumnCheck,
    getRole,
    getCommander,
    getSupportRole,
    resultP = {},
    currentRole,
    nextRole,
    processType,
    typePage = '',
    processeds = [],
    supporteds = [],
    supporters = [],
    moduleCode,
    isReturn = false,
    open = false,
    roleP,
    typeDoc = '',
    profile,
    hasOneColumn,
    childTemplate,
    docIds,
    getFlag,
    checkOrg,
    roleDirection,
    sendUnit,
    allowSendToUnit,
    byOrg,
    unit,
    organizationUnit,
    rootTab,
    setIsFirstID,
    isReturnDoc,
    checkDocument
  } = props;
  let timeout = 0;
  const [data, setData] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [departmentsClone, setDepartmentsClone] = useState([]);
  const [checkFirst, setCheckFirst] = useState(0);
  const [firstId, setFirstId] = useState();
  const [listJoined, setListJoined] = useState([]); // danh sách người đã tham gia xử lý
  const [organizationData, setOrganizationData] = useState([]); // danh sách đầu phòng đã tham gia xử lý
  const [organizationParent, setOrganizationParent] = useState(); // danh sách đầu phòng đã tham gia xử lý




  const [listRoleLevel, setListRoleLevel] = useState({});
  const [listRoleLevelAndName, setListRoleLevelAndName] = useState([]);


  const [columns, setColumns] = useState([
    {
      name: 'view',
      title: 'Xem',
      _id: '5fb3ad613918a44b3053f080',
    },

  ]);

  const [history, setHistory] = useState([]);
  const isRoom = profile && profile.canProcessAny && profile.workingOrganization && !profile.workingOrganization.parent ? true : false;
  const [employees, setEmployees] = useState();
  const [cloneEpl, setCloneEpl] = useState([]);
  const [search, setSearch] = useState((props.childTemplate && props.childTemplate.name || props.type === "flow" || props.type === "startFlow") ? " " : []);
  const [role, setRole] = useState({});
  const [userOrg, setUserOrg] = useState(null);
  const [countObj, setCountObj] = useState({});
  const [reload, setReload] = useState(new Date() * 1);




  const [checkAll, setCheckAll] = useState({
    support: false,
    view: false,
    processing: false
  });

  let urlCurrent =
    moduleCode && typePage !== '' ? `${API_ROLE_APP}/${moduleCode}/currentUser?authority=true` : `${API_ROLE_APP}/${moduleCode}/currentUser`;
  useEffect(
    () => {
      if (Array.isArray(columnSettings)) {
        let newColumnSettings = [...columnSettings];
        if (!role.processing_set_command) {
          newColumnSettings = newColumnSettings.filter(c => c.name !== 'command');
        }
        // setColumns(newColumnSettings);
        let newColumn = [
          {
            name: "command",
            title: "Chỉ đạo",
            _id: "5fb3ad613918a44b3053f080",
            allowSelectDepartment: false,
            isColumnVirtual: true
          },
          {
            name: "processing",
            title: "Xử lý chính",
            _id: "5fb3ad613918a44b3053f080",
            allowSelectDepartment: true,
            isColumnVirtual: true
          },
          {
            name: "support",
            title: "Phối hợp",
            _id: "5fb3ad613918a44b3053f080",
            allowSelectDepartment: true,
            isColumnVirtual: true
          },
          {
            name: "view",
            title: "Nhận để biết",
            _id: "5fb3ad613918a44b3053f080",
            allowSelectDepartment: true,
            isColumnVirtual: true
          }
        ]
        newColumn = newColumn.map((el) => {
          const columnFind = newColumnSettings.find((e) => e.name === el.name)
          if (columnFind) return columnFind
          return el
        })
        setColumns(newColumn)
      }
    },
    [columnSettings, role],
  );
  // const checkProcess = (id) => {
  //   let canProcess = true
  //   history.length > 0 && history.map((el) => {
  //     el.childs && Array.isArray(el.childs) && el.childs.length > 0 && el.childs.map((it) => {
  //       if (it.action === "Xử lý chính" && it.stageStatus === "Chưa xử lý")
  //         if (it.receiver && it.receiver._id && it.receiver._id === id) canProcess = false
  //     })
  //   })
  //   return canProcess
  // }
  // useEffect(() => {
  //   const query = { filter: { docId: docIds } };
  //   fetch(`${API_DOCUMENT_HISTORY}?${serialize(query)}`, {
  //     method: 'GET',
  //     headers: {
  //       Authorization: `Bearer ${localStorage.getItem('token')}`,
  //     },
  //   })
  //     .then(response => response.json())
  //     .then(data => {
  //       setHistory(data)
  //     })
  // }, [])
  useEffect(() => {
    setListRoleLevel(localStorage.getItem('roleGroups') ? JSON.parse(localStorage.getItem('roleGroups')) : {})
    setListRoleLevelAndName(localStorage.getItem('roleGroupsAndName') ? JSON.parse(localStorage.getItem('roleGroupsAndName')) : [])

  }, [])
  useEffect(() => {
    if (moduleCode) {
      fetchData(urlCurrent).then(res => {
        const { roles } = res;
        const code = 'BUSSINES';

        const foundRoleDepartment = Array.isArray(roles) && roles.find(it => it.code === code);
        if (foundRoleDepartment) {
          const { data } = foundRoleDepartment;
          const newRole = {};
          data.forEach(rol => {
            Object.keys(rol.data).forEach(key => {
              newRole[`${rol.name}_${key}`] = rol.data[key];
            });
          });
          setRole(newRole);
        }
      });
    }
  }, []);
  useEffect(() => {
    if (listJoined && listJoined.length || organizationData && organizationData.length) {
      props.handleCheckProcess && props.handleCheckProcess(true)

    } else props.handleCheckProcess && props.handleCheckProcess(false)

  }, [listJoined, organizationData])
  useEffect(
    () => {
      getData();
      if (open) {
        if ((type === '' || type === 'flow') && !isReturnDoc) {
          // k là lấy ds trả lại
          const query = { filter: {} };
          if (docIds && docIds.length) {
            query.docIds = docIds;
          }
          if (isReturn) {
            query.isReturn = isReturn;
          }
          if (Array.isArray(childTemplate) && roleP !== 'supporters') {
            let and = [];
            let role = [];
            childTemplate.map(child => {
              if (processType === 'any' && profile && profile.canProcessAny) {
                // if (child.type !== '') {
                //   role.push({
                //     roleGroupSource: child.code
                //   })
                // }
              } else {
                if (child.type !== '') {
                  and = [
                    {
                      type: child.type,
                    },
                    {
                      roleGroupSource: child.code,
                    },
                  ];
                } else {
                  role.push({
                    roleGroupSource: child.code,
                  });
                }
              }
            });
            let or = and.length === 0 ? role : [{ $and: [...and] }, ...role];
            query.filter['$or'] = [...or];
          }
          if (!Array.isArray(childTemplate) && role !== 'supporters' && currentRole) {
            query.filter.roleGroupSource = currentRole;
          }

          if (roleP === 'supporters' && supporteds && supporteds.length > 0) {
            query.filter._id = { $nin: supporteds };
          }

          if (roleP === 'commander' && supporters && supporters.length > 0) {
            query.filter._id = { $nin: supporters };
          }
          if (processType === 'any') {
            query.isAny = true;
          }
          if (processType === 'any' && sendUnit) {
            query.unit = sendUnit;
          }
          if (processType === 'any' && props.roleReceive && roleP === "receive") {
            query.roleReceive = props.roleReceive
          }
          // if (processType === 'any' && allowSendToUnit) {
          //   query.allowSendToUnit = allowSendToUnit;
          // }

          // 06/12/2022 bỏ để lấy đc theo role
          // if (roleP === 'commander') {
          //   query.isCommand = roleP;
          // }
          if ((processType === 'flow') && unit) {
            query.unit = unit;
          }
          // let roleDirection = Array.isArray(props.childTemplate) && props.childTemplate.length > 0 && props.childTemplate[0].roleDirection ? props.childTemplate[0].roleDirection : null
          // if (Array.isArray(props.childTemplate) && props.childTemplate.length) {
          // }
          let urlListUser;
          query.disable = "on"; // sửa luồng để hiện lại ng đã xlc
          if (props.processType === 'flow') {
            if (roleP !== 'supporters') {
              urlListUser =
                typePage !== ''
                  ? `${API_INCOMMING_DOCUMENT}/list-user?authority=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}`
                  : `${API_INCOMMING_DOCUMENT}/list-user?${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}`;
              urlListUser = typeDoc !== '' ? `${urlListUser}&type=${typeDoc}` : urlListUser;
            } else {
              // query.filter['organizationUnit.organizationUnitId'] = profile && profile.organizationUnit && profile.organizationUnit.organizationUnitId;
              urlListUser =
                typePage !== ''
                  ? `${API_INCOMMING_DOCUMENT}/list-user?&authority=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}`
                  : `${API_INCOMMING_DOCUMENT}/list-user?&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}`;
              urlListUser = typeDoc !== '' ? `${urlListUser}&type=${typeDoc}` : urlListUser;
            }
          } else {
            if (roleP !== 'supporters') {
              if (typeReturn) {
                urlListUser =
                  typePage !== ''
                    ? `${API_INCOMMING_DOCUMENT}/list-user?isFlow=true&authority=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`
                    : `${API_INCOMMING_DOCUMENT}/list-user?isFlow=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`;
                urlListUser = typeDoc !== '' ? `${urlListUser}&type=${typeDoc}` : urlListUser;
              } else {

                urlListUser =
                  typePage !== ''
                    ? `${API_INCOMMING_DOCUMENT}/list-user?authority=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`
                    : `${API_INCOMMING_DOCUMENT}/list-user?${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`;
                urlListUser = typeDoc !== '' ? `${urlListUser}&type=${typeDoc}` : urlListUser;
              }
            } else {
              // query.filter['organizationUnit.organizationUnitId'] = profile && profile.organizationUnit && profile.organizationUnit.organizationUnitId;
              urlListUser =
                typePage !== ''
                  ? `${API_INCOMMING_DOCUMENT}/list-user?&authority=true&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`
                  : `${API_INCOMMING_DOCUMENT}/list-user?&${serialize(query)}&checkOrg=${checkOrg !== undefined ? checkOrg : false}${roleDirection ? `&roleDirection=${roleDirection}` : ''}`;
              urlListUser = typeDoc !== '' ? `${urlListUser}&type=${typeDoc}&support=true` : `${urlListUser}&support=true`;
            }
          }
          fetchData(urlListUser)
            .then(response => {
              if (response && response.organizationData) {
                let listOrganizationJoined = response.organizationData || []
                listOrganizationJoined = listOrganizationJoined.filter((it) => it.checkHidden && (it.checkHidden.command || it.checkHidden.processing || it.checkHidden.support || it.checkHidden.view))
                const organizationUnitId = profile && profile.organizationUnit && profile.organizationUnit.organizationUnitId
                if(organizationUnitId){
                  listOrganizationJoined = listOrganizationJoined.filter((it)=>it._id !== organizationUnitId)
                }
                setOrganizationData(listOrganizationJoined || [])
                // props.handleCheckProcess && props.handleCheckProcess(response.organizationData)

              }
              else {
                setOrganizationData([])
              }
              if (response && response.data) {
                const data = response.data || []
                const foundProccess = data.filter((it) => it.checkHidden && (
                  it.checkHidden.command ||
                  it.checkHidden.processing ||
                  it.checkHidden.support ||
                  it.checkHidden.view
                ))
                // props.handleCheckProcess && props.handleCheckProcess(foundProccess)
                setListJoined(foundProccess)

                if (roleP === 'supporters') {
                  setEmployees(response.data);
                  setCloneEpl(response.data);
                } else {
                  setUserOrg(response.currentEmployee.organizationUnit.organizationUnitId);
                  let newUsers = response.data.map(e => convertDot({ ob: e, newOb: { organizationUnit: e.organizationUnit } }));
                  if (type === 'flow' && processeds && allowedUsers && allowedUsers.length > 0) {
                    let sortAllow = [];
                    processeds.map((item, index) => {
                      allowedUsers.map(allow => {
                        if (allow._id === item) {
                          sortAllow[index] = allow;
                        }
                      });
                    });
                    sortAllow = sortAllow.filter(f => f);
                    newUsers = newUsers.map(item => {
                      sortAllow =
                        sortAllow &&
                        sortAllow.filter(user => user.roleGroupSource === item.roleGroupSource);
                      return sortAllow[sortAllow.length - 1];
                    });
                    if (newUsers.length === 0) {
                      newUsers = [...sortAllow];
                    }
                    newUsers = [...new Set(newUsers)];
                  }
                  const foundProccess = newUsers.filter((it) => (
                    it["checkHidden.command"] ||
                    it["checkHidden.processing"] ||
                    it["checkHidden.support"] ||
                    it["checkHidden.view"]
                  ))
                  // props.handleCheckProcess && props.handleCheckProcess(foundProccess)

                  setListJoined(foundProccess)

                  setEmployees(newUsers);
                  setCloneEpl(newUsers);
                }
              }
            })
            .catch(e => {
            });
        } else {
          const foundProccess = allowedUsers.filter((it) => it.checkHidden && (
            it.checkHidden.command ||
            it.checkHidden.processing ||
            it.checkHidden.support ||
            it.checkHidden.view
          ))
          // props.handleCheckProcess && props.handleCheckProcess(foundProccess)

          setListJoined(foundProccess)
          allowedUsers && setEmployees(allowedUsers);
          allowedUsers && setCloneEpl(allowedUsers);
        }
      }
    },
    [open, currentRole, type, allowedUsers],
  );
  useEffect(
    () => {
      let employeesFilter;

      if (search.length > 0) {
        employeesFilter =
          cloneEpl && cloneEpl.filter(item => item && item.name && removeVietnameseTones(item.name.toLowerCase()).includes(removeVietnameseTones(search.toLowerCase())));
      } else {
        employeesFilter = cloneEpl;
      }
      // if (Array.isArray(departments) && departments.length === 0)
      //   setCount(!count)
      if (search.length > 0) {
        departments.forEach(item => {
          employeesFilter.forEach(ele => {
            if (item._id === ele['organizationUnit.organizationUnitId'] || ele && ele.organizationUnit && item && item._id && item._id === ele.organizationUnit.organizationUnitId) {
              const arr = item.slug.split('/');
              departments.forEach(items => {
                if (items.slug.includes(arr[0])) {
                  items.expand = true;
                  items.open = true;
                }
              });
            }
          });
        });
      } else {
        const { infor = {}, profile } = props
        const { typeDoc } = infor
        let organization = []
        if (typeDoc === "preliminaryDoc" && organizationParent) {
          organization.push(organizationParent)
        } else {
          const CurrentOrganizationUnit = props.profile && props.profile.organizationUnit && props.profile.organizationUnit.organizationUnitId
          const derpartmentFount = departments.find((it => it._id === CurrentOrganizationUnit))
          if (derpartmentFount) {
            const slug = derpartmentFount.slug.split("/")
            organization = [...organization, ...slug]
          } else {
            organization.push(organizationParent)
          }
        }
        organization = organization.filter(it => it)
        const organizationClone = organization
        // organizationClone.pop()
        departments.forEach(async (item, index) => {

          // if (item.parent === null) {
          // if (organization.includes(item.name) ||item.parent === null ) {
          if (!item.parent || organization.includes(item.name)) {
            item.open = true;
            item.expand = true;
          }
          else if (organizationClone.includes(item.parent)) {
            item.open = true;
            item.expand = false;
          }
          else {
            item.open = false;
            item.expand = false;
          }
        });
      }
      setEmployees(employeesFilter);
    },
    [search, cloneEpl, departmentsClone],
  );
  useEffect(
    () => {
      if ((allowedDepartmentIds, departments, employees)) {
        setData(mergeDerpartment(data, departments, employees, allowedUsers));
      }
    },
    [allowedDepartmentIds, departments, employees, allowedUsers],
  );

  const removeVietnameseTones = str => {
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
    str = str.replace(/đ/g, 'd');
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
    str = str.replace(/Đ/g, 'D');
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, '');
    str = str.replace(/\u02C6|\u0306|\u031B/g, '');
    str = str.replace(/ + /g, ' ');
    str = str.trim();
    str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, ' ');
    return str;
  };
  const unique = arr => {
    return Array.from(new Set(arr)); //
  };
  const clearDer = () => { };
  const getData = async (listEmp = []) => {
    try {
      const departmentsRes = await fetchData(
        `${API_ORIGANIZATION}?processType=${props.template && props.template[0] ? props.template[0].type : null}&processId=${props.template && props.template[0] ? props.template[0]._id : null
        }${docIds && docIds[0] ? `&docId=${docIds[0]}` : ''}`,
      );
      // const departmentsRes = await fetchData(`${API_ORIGANIZATION}`);

      const flattedDepartment = flatChildOpen(departmentsRes);
      setOrganizationParent(flattedDepartment && flattedDepartment[0] && flattedDepartment[0]._id)
      flattedDepartment.forEach((item, index) => {
        if (item.parent === null) {
          item.open = true;
          item.expand = false;
        } else {
          item.open = false;
          item.expand = false;
        }
      });
      setDepartments(flattedDepartment);
      setDepartmentsClone(flattedDepartment)
    } catch (error) { }
  };
  const handleSearch = e => {
    const search = e.target.value;
    // if (timeout) clearTimeout(timeout);
    // timeout = setTimeout(() => {
    //   setSearch(search);
    // }, 500);
    setSearch(search);
    // const data2 = _.cloneDeep(employees)
    // data2.forEach((item,index) => {
    //   const dataFilter = item && item.users && item.users.filter(item => item.userName.includes(search))
    //   data2[index].users = dataFilter
    // })
    // setDepartments(departFilter)
  };
  // useEffect(() => {
  //   if (firstId && checkFirst && columns && Array.isArray(columns)) {
  //     setTimeout(() => {
  //       handleCheckUser(firstId, 'processing', 0)
  //     }, 1000);
  //   }

  // }, [checkFirst, firstId, columns])
  function mergeDerpartment(data, departments, users = [], allowedEmployees = [], result) {
    let level = -1;
    const newCountObj = {};
    const findOrg = departments.find(i => i.id === userOrg);
    if (findOrg) {
      level = findOrg.level;
    }
    const x = departments.map((i, index) => {
      let disableSetProcess = false;
      // if (roleP !== 'supporters') {
      //   if (type === '' && i.level >= level && !i.slug.includes(userOrg)) {
      //     disableSetProcess = true;
      //   }
      // } else {
      //   disableSetProcess = false
      // }

      const dataIndex = data[index];
      const departmentUsers = (
        users.filter(u => u && u.organizationUnit && u.organizationUnit.organizationUnitId === i.id && !disableSetProcess) || []
      )
        .sort((a, b) => {
          if (roleGroupsOrder && (roleGroupsOrder[b.roleGroupSource] || 0) > (roleGroupsOrder[a.roleGroupSource] || 0)) {
            return -1;
          }
          if (roleGroupsOrder && (roleGroupsOrder[b.roleGroupSource] || 0) < (roleGroupsOrder[a.roleGroupSource] || 0)) {
            return 1;
          }
          return 0;
        })
        .map(u => {
          let dataCheck
          if (!checkFirst && (typeFlow === "startFlow" || typeFlow === "backFlow")) {
            setCheckFirst(1)
            setIsFirstID && setIsFirstID([u._id])
            dataCheck = { view: false, edit: false, delete: false, processing: true };
          }
          else if (typeFlow === "startFlow" || typeFlow === "backFlow")
            dataCheck = { view: false, edit: false, delete: false, processing: false }
          else dataCheck = { view: false, edit: false, delete: false }
          if (dataIndex && dataIndex.users) {
            const findUser = dataIndex.users.find(ui => ui.id === u._id);
            if (findUser) {
              dataCheck = findUser.data;
            }
          }
          return {
            ...u,
            is_user: true,
            // userName: getName(u),
            userNameCopy: u.name,
            userName: u.name,
            open: u.open,
            name: u.id,
            id: u._id,
            expand: u.expand,
            slug: u.slug,
            data: dataCheck,
            disableSetProcess,
          };
        });
      newCountObj[i._id] = departmentUsers.length;
      const slugArr = i.slug.split('/');
      slugArr.pop();
      slugArr.forEach(idOrg => {
        if (isNaN(newCountObj[idOrg])) {
          newCountObj[idOrg] = 0;
          1;
        }
        newCountObj[idOrg] += departmentUsers.length;
      });
      return {
        open: i.open,
        name: i.id,
        id: i.id,
        expand: true,
        slug: i.slug,
        data: dataIndex ? dataIndex.data : { view: false, edit: false, delete: false },
        users: departmentUsers,
        allowedSelectDepartment: i.level > level,
      };
    });
    setCountObj(newCountObj);
    return x;
  }

  function handleCheckDerpartment(name, valueName, checked) {
    const slug = data.find(i => i.name === name).slug;
    const list = slug.split('/');
    const newAllowedUsers = [...allowedUsers] || [];
    const newData = data.map(
      i =>
        (i.slug === slug || list.includes(i.name) && checked)
          ? {
            ...i,
            data: { [valueName]: !checked },
            users: i.users.map(it => {
              if (rootTab === "receive" && processType === "any") {
                // " tiếp nhận tùy chọn nè"
                //  return {
                //   ...it,
                //   data: {
                //     ...it.data
                //   },
                // };
                return it
              }
              else
                return {
                  ...it,
                  data: {
                    ...it.data,
                    // [valueName]:false
                    [valueName]: valueName === 'processing' && i.slug === slug ? checked : it.data[valueName],
                  },
                };
            }),
          }
          : {
            ...i,
            data: i.data,
            users: i.users.map(it => {
              return {
                ...it,
                // data: valueName === 'processing' && !(rootTab === "receive" && processType === "any") ? { ...it.data, [valueName]: false } : it.data,
                data: valueName === 'processing' && i.slug === slug ? { ...it.data, [valueName]: !checked } : it.data,


              };
            }),
          },
    );
    let roleSupport = [];
    setData(newData)
    const viewedDepartmentIds = newData.filter(item => item.data.view).map(item => item.name);
    if (columnSettings && columnSettings.length) {
      const result = { ...resultP };
      columnSettings.forEach(c => {
        result[c.name] = newData.filter(item => item.data[c.name]) && newData.filter(item => item.data[c.name]).map(item => item.name);
        // chi dao gap van de

        // đầu phòng thì bỏ người đi
        // result[`${c.name}Users`] = (result[`${c.name}Users`] && [...result[`${c.name}Users`]]) || [...result[`${c.name}`]];
        result[`${c.name}Users`] = (result[`${c.name}Users`] && [...result[`${c.name}Users`]]) || [];
        newData.forEach(rowData => {
          rowData.users &&
            rowData.users.forEach(u => {
              if (c.name !== 'processing' && rowData.data[c.name]) {
                if (c.name === 'command') {
                  if (result[`${c.name}Users`].indexOf(u.id) === -1) {
                    result[`${c.name}Users`].push(u.id);
                  }
                  getCommander && getCommander(u.roleGroupSource);
                }
                if (c.name === 'support') {
                  if (roleSupport.indexOf(u.roleGroupSource) === -1) {
                    roleSupport.push(u.roleGroupSource);
                  }
                  if (roleSupport.length > 0) {
                    let totalRole = roleSupport.reduce((str, i, index) => (str += index === roleSupport.length - 1 ? i : i + ','), '');
                    // giờ k còn chuyển đầu phòng phối hợp về ng trong luồng xl nữa mà là về văn thư
                    // getSupportRole && getSupportRole(totalRole);
                  }
                }
              }
              if (c.name === 'processing' && rowData.data[c.name]) {
                if (u['roleCached.IncommingDocument.processing_department_incharge'] == true) {
                  if (result[`${c.name}Users`].indexOf(u.id) === -1) {
                    // result[`${c.name}Users`].push(u.id);
                  }
                  getRole && getRole(u.roleGroupSource);
                }
              }
            });
        });
        if (onChangeColumnCheck) {
          onChangeColumnCheck(result, departments);
        }
      });
    }
    if (onChangeAddRoles) onChangeAddRoles(newData, departments);
    if (onChange) onChange(viewedDepartmentIds, newAllowedUsers);
  }
  function handleCheckDerpartmentAll(name, valueName, checked) {
    const slug = dataProcess.find(i => i.name === name).slug;
    const list = slug.split('/');
    const newAllowedUsers = [...allowedUsers] || [];
    const newData = dataProcess.map(
      i =>
        i.slug === slug || (list.includes(i.name) && checked)
          ? {
            ...i,
            data: { [valueName]: !checked },
            users: i.users.map(it => {
              if (rootTab === "receive" && processType === "any") {
                // " tiếp nhận tùy chọn nè"
                return {
                  ...it,
                  data: {
                    ...it.data
                  },
                };
              }
              else
                return {
                  ...it,
                  data: {
                    ...it.data,
                    [valueName]: false,
                  },
                };
            }),
          }
          : {
            ...i,
            data: i.data,
            users: i.users.map(it => {
              return {
                ...it,
                // data: valueName === 'processing' && !(rootTab === "receive" && processType === "any") ? { ...it.data, [valueName]: false } : it.data,
                data: valueName === 'processing' ? { ...it.data, [valueName]: false } : it.data,

              };
            }),
          },
    );
    let roleSupport = [];
    // setData(newData)
    dataProcess = [...newData]
    const viewedDepartmentIds = newData.filter(item => item.data.view).map(item => item.name);
    const result = { ...resultP };

    if (columnSettings && columnSettings.length) {
      columnSettings.forEach(c => {
        result[c.name] = newData.filter(item => item.data[c.name]) && newData.filter(item => item.data[c.name]).map(item => item.name);
        // chi dao gap van de

        // đầu phòng thì bỏ người đi
        // result[`${c.name}Users`] = (result[`${c.name}Users`] && [...result[`${c.name}Users`]]) || [...result[`${c.name}`]];
        result[`${c.name}Users`] = (result[`${c.name}Users`] && [...result[`${c.name}Users`]]) || [];
        dataProcess.forEach(rowData => {
          rowData.users &&
            rowData.users.forEach(u => {
              if (c.name !== 'processing' && rowData.data[c.name]) {
                if (c.name === 'command') {
                  if (result[`${c.name}Users`].indexOf(u.id) === -1) {
                    result[`${c.name}Users`].push(u.id);
                  }
                  // getCommander && getCommander(u.roleGroupSource);
                }
                if (c.name === 'support') {
                  if (roleSupport.indexOf(u.roleGroupSource) === -1) {
                    roleSupport.push(u.roleGroupSource);
                  }
                  if (roleSupport.length > 0) {
                    let totalRole = roleSupport.reduce((str, i, index) => (str += index === roleSupport.length - 1 ? i : i + ','), '');
                    // getSupportRole && getSupportRole(totalRole);
                  }
                }
              }
              if (c.name === 'processing' && rowData.data[c.name]) {
                if (u['roleCached.IncommingDocument.processing_department_incharge'] == true) {
                  if (result[`${c.name}Users`].indexOf(u.id) === -1) {
                    result[`${c.name}Users`].push(u.id);
                  }
                  getRole && getRole(u.roleGroupSource);
                }
              }
            });
        });
        if (onChangeColumnCheck) {
          onChangeColumnCheck(result, departments);
        }
      });
    }
    if (onChangeAddRoles) onChangeAddRoles(newData, departments);
    if (onChange) onChange(viewedDepartmentIds, newAllowedUsers);
    return result
  }
  const getName = (item) => {
    const role = item && (item.roleGroupSourceAuthorized || item.roleGroupSource) || ""
    const roleAcc = listRoleLevelAndName.find(element => element.code === role);
    if (roleAcc && roleAcc.order <= MIN_ORDER) {
      let name = ""
      if (item.nameAuthorized) {
        // item.roleGroupSourceAuthorized || item.roleGroupSource
        name = `${item.nameAuthorized} - ${roleAcc && roleAcc.name || " "} (Người được ${item.userNameCopy} ủy quyền)`
      } else {
        name = `${item.userNameCopy} - ${roleAcc && roleAcc.name || " "}`
      }
      return name || item.nameAuthorized || item.userNameCopy
    }
    else {
      let name = ""
      if (item.nameAuthorized) {
        // item.roleGroupSourceAuthorized || item.roleGroupSource
        name = `${item.nameAuthorized} - (Người được ${item.userNameCopy} ủy quyền)`
      } else {
        name = `${item.userNameCopy}`
      }
      return name || item.nameAuthorized || item.userNameCopy
    }
    return item && (item.nameAuthorized || item.userNameCopy) || ""
  }
  const getNameOfUserName = (userName) => {
    let fullName = userName && (userName.nameAuthorized || userName.userNameCopy) || ""
    fullName = fullName ? fullName.trim() : ""
    const idx = fullName.lastIndexOf(" ")
    return fullName.slice(idx) || ""
  }
  const sortAZ = (list) => {
    let listUser = list
    let listRole = []
    for (const property in listRoleLevel) {
      listRole.push({
        name: property,
        value: listRoleLevel[property]
      })
    }
    listRole = _.sortBy(listRole, ["value"])
    let listUserany = []
    listRole.map((el) => {
      let lisst = []
      for (let i = 0; i < listUser.length; i++) {
        let role = listUser[i]["roleGroupSourceAuthorized"] ? listUser[i]["roleGroupSourceAuthorized"] : listUser[i]["roleGroupSource"]
        if ((role === el.name)) {
          lisst.push(listUser[i])
        }
      }
      listUserany.push(lisst)
    })
    for (let i = 0; i < listUserany.length; i++) {
      for (let j = 0; j < listUserany[i].length - 1; j++) {
        for (let k = j + 1; k < listUserany[i].length; k++) {
          if (getNameOfUserName(listUserany[i][j]).localeCompare(getNameOfUserName(listUserany[i][k])) == 1) {
            let temp = listUserany[i][j];
            listUserany[i][j] = listUserany[i][k]
            listUserany[i][k] = temp
          }
        }
      }
    }
    let data = []
    for (let i = 0; i < listUserany.length; i++) {
      data = [...data, ...listUserany[i]]
    }
    listUser = data

    listUser.map((el) => el.userName = getName(el))
    return listUser || []
  }
  function handleCheckUser(userId, columnName, rowIndex, user) {
    setIsFirstID && setIsFirstID()
    if (!userId || !user) return;
    const { organizationUnitId } = user.organizationUnit && user.organizationUnit.organizationUnitId
    if (columnSettings && columnSettings.length) {
      const newData = [...data];
      for (let i = 0; i < newData.length; i += 1) {
        newData[rowIndex].data[columnName] = false;
        if (rootTab === "receive" && processType === "any") {
          if (columnName === 'processing' || columnName === 'command') {
            // không bỏ tích khi chuyển tùy chọn tiếp nhận
            // newData[i].data[columnName] = false;
            // newData[i].users.filter(u => u.id !== userId).map(item => {
            //   item.data[columnName] = false;
            // });
          }
        }
        else {
          if (columnName === 'processing' || columnName === 'command') {
            newData[i].data[columnName] = organizationUnitId === newData[i].name ? false : newData[i].data[columnName];
            newData[i].users.filter(u => u.id !== userId).map(item => {
              item.data[columnName] = false;
            });
          }
        }

      }

      let user = newData[rowIndex].users.find(u => u.id === userId) || {};
      if (user.data) {
        Object.keys(user.data).map(item => {
          if (item != columnName) {
            user.data[item] = false;
          }
        });
      }
      user.data[columnName] = !user.data[columnName];

      const result = { ...resultP };
      let roleSupport = [];
      const newUser = []
      columnSettings.forEach(c => {
        result[c.name] = newData.filter(item => item.data[c.name]).map(item => item.name);
        // let tempData =result[`${c.name}Users`]
        result[`${c.name}Users`] = [];
        newData.forEach(rowData => {
          rowData.users &&
            rowData.users.forEach(u => {
              if (c.name !== 'processing' && u.data[c.name]) {
                result[`${c.name}Users`].push(u.id);
                if (c.name === 'command') {
                  getCommander && getCommander(u.roleGroupSource);
                }
                if (c.name === 'support') {
                  if (roleSupport.indexOf(u.roleGroupSource) === -1) {
                    roleSupport.push(u.roleGroupSource);
                  }
                  if (roleSupport.length > 0) {
                    let totalRole = roleSupport.reduce((str, i, index) => (str += index === roleSupport.length - 1 ? i : i + ','), '');
                    getSupportRole && getSupportRole(totalRole);
                  }
                }
              }
              if (c.name === 'processing' && u.data[c.name]) {
                if (rootTab === "receive" && processType === "any") {
                  // let dataUser = result[`${c.name}Users`] || []
                  // dataUser.push(u.id)
                  // dataUser = unique(dataUser)
                  // result[`${c.name}Users`] = dataUser

                  // result[`${c.name}Users`] = [u.id]
                  // getRole && getRole(u.roleGroupSource);


                  newUser.push(u.id)
                  // result[`${c.name}`] = [u.id]
                  getRole && getRole(u.roleGroupSource);
                } else {
                  result[`${c.name}Users`] = [u.id];
                  getRole && getRole(u.roleGroupSource);
                }

              }
            });
        });
        if (rootTab === "receive" && processType === "any") {
          // khi mà chuyển bất kì chọn đích danh thì dùng cái này
          result[`${c.name}Users`] = newUser
        }
        if (onChangeColumnCheck) {
          onChangeColumnCheck(result, departments);
        }
      });
      return;
    }
    const newAllowedUsers = [...allowedUsers];
    const index = newAllowedUsers.findIndex(u => u === userId);
    if (index === -1) {
      newAllowedUsers.push(userId);
    } else {
      newAllowedUsers.splice(index, 1);
    }
    if (onAllowedUsersChange) {
      onAllowedUsersChange(newAllowedUsers);
    }
  }
  const handleCheckUserAll = columnName => {
    const { info = {} } = props
    const { typeDoc } = info
    const CurrentOrganizationUnit = props.profile && props.profile.organizationUnit && props.profile.organizationUnit.organizationUnitId
    let listDepartmentsAcceps
    // if (typeDoc === "preliminaryDoc") {
    if (checkDocument) {
      listDepartmentsAcceps = departments.filter((it) => {
        return organizationParent != it._id && (it.level === 1) && allowSendToUnit
      }) // chỉ lấy ds phòng ban 1 cấp và k phải đơn vị tạo bỏ khi k có quyền tích đầu phòng
    } else {
      listDepartmentsAcceps = departments.filter((it) => {
        return organizationParent != it._id && it.parent === CurrentOrganizationUnit && allowSendToUnit
      }) // chỉ lấy ds phòng ban 1 cấp và k phải đơn vị tạo bỏ khi k có quyền tích đầu phòng
    }
    // let listDepartmentsAcceps = departments.filter((it) => {
    //   return organizationParent != it._id && (it.level === 0 || it.level === 1) && allowSendToUnit
    // }) // chỉ lấy ds phòng ban 1 cấp và k phải đơn vị tạo bỏ khi k có quyền tích đầu phòng


    // let listDepartmentsAcceps = departments.filter((it) => {
    //   return organizationParent != it._id && it.parent === CurrentOrganizationUnit && allowSendToUnit
    // }) // chỉ lấy ds phòng ban 1 cấp và k phải đơn vị tạo bỏ khi k có quyền tích đầu phòng



    listDepartmentsAcceps = listDepartmentsAcceps.map((el) => el._id)
    const listJoinOrganizationData = organizationData.map((it) => it._id)
    listDepartmentsAcceps = listDepartmentsAcceps.filter((it) => !listJoinOrganizationData.includes(it)) // bỏ các đơn vị đã tham gia

    const { commandUsers = [], processingUsers = [], supportUsers = [], viewUsers = [], support = [], view = [], processing = [] } = resultP
    if (columnSettings && columnSettings.length) {
      dataProcess = data
      const newData = [...data];
      let listUser = [];
      const currentCheckAll = checkAll[columnName]

      if (columnName === 'view') setCheckAll({ view: !checkAll.view, support: false });
      else setCheckAll({ view: false, support: !checkAll.support });
      newData.map(el => {
        if (el.users && Array.isArray(el.users) && el.users.length > 0)
          el.users.map(user => {
            listUser.push(user);
          });
      });
      const listJoin = listJoined.map((it) => it._id)
      let newList = listUser // danh sách k có ng đã xử lý
      if (listJoin && listJoin.length) {
        // bỏ ng đã tham gia xử lý
        newList = listUser.filter((it) => !listJoin.includes(it._id))

      }

      // if (typeDoc === "preliminaryDoc") {
      if (checkDocument) {
        newList = newList.filter((it) => it && (it["organizationUnit.organizationUnitId"] === organizationParent) || (it.organizationUnit && it.organizationUnit.organizationUnitId === organizationParent)) // chỉ lấy người cấp 1

      } else {
        newList = newList.filter((it) => it && (it["organizationUnit.organizationUnitId"] === CurrentOrganizationUnit) || (it.organizationUnit && it.organizationUnit.organizationUnitId === CurrentOrganizationUnit)) // chỉ lấy người cấp 1 theo tk đăng nhập
      }

      if (listJoinOrganizationData && listJoinOrganizationData.length) {
        // bỏ ng có đơn vị đã tham gia xử lý
        newList = newList.filter((it) => !listJoinOrganizationData.includes(it["organizationUnit.organizationUnitId"]))

      }

      // handleCheckDerpartment(row, column, checked);

      //  tích

      listUser = newList;
      if (listUser && Array.isArray(listUser) && listUser.length > 0) {
        listUser.map(user => {
          Object.keys(user.data).map(item => {
            if (item != columnName && checkAll[columnName] === false) {
              // user.data[item] = false;
              // if(commandUsers.includes(user._id)){
              // }
              // else if(processingUsers.includes(user._id)){
              // }else {
              //   user.data[item] = false;
              // }

              if (columnName === "support") {
                if (commandUsers.includes(user._id) || processingUsers.includes(user._id)) {
                } else {
                  user.data[item] = false;
                }
              } else if (columnName === "view") {
                if (commandUsers.includes(user._id) || processingUsers.includes(user._id) || supportUsers.includes(user._id)) {
                } else {
                  user.data[item] = false;;
                }
              } else {
                user.data[item] = false;
              }
            }
          });
          if (checkAll[columnName] === true) {
            // user.data[columnName] = false;


            if (columnName === "support") {
              if (commandUsers.includes(user._id) || processingUsers.includes(user._id)) {
              } else {
                user.data[columnName] = false;
              }
            } else if (columnName === "view") {
              if (commandUsers.includes(user._id) || processingUsers.includes(user._id) || supportUsers.includes(user._id)) {
              } else {
                user.data[columnName] = false;
              }
            } else {
              user.data[columnName] = false;
            }


          }
          else {
            // user.data[columnName] = true;
            if (columnName === "support") {
              if (commandUsers.includes(user._id) || processingUsers.includes(user._id)) {
              } else {
                user.data[columnName] = true;
              }
            } else if (columnName === "view") {
              if (commandUsers.includes(user._id) || processingUsers.includes(user._id) || supportUsers.includes(user._id)) {
              } else {
                user.data[columnName] = true;
              }
            } else {
              user.data[columnName] = true;
            }
          }
        });
      }
      let result = { ...resultP };
      let roleSupport = [];
      columnSettings.forEach(async c => {
        result[c.name] = newData.filter(item => item.data[c.name]).map(item => item.name);
        result[`${c.name}Users`] = [];
        result[`${c.name}`] = [];
        newData.forEach(rowData => {
          rowData.users &&
            rowData.users.forEach(u => {
              if (c.name !== 'processing' && u.data[c.name]) {
                if (columnName === "support") {
                  if (commandUsers.includes(u.id)) {
                    result["commandUsers"].push(u.id);
                  }
                  else if (processingUsers.includes(u.id)) {
                    result["processingUsers"].push(u.id);
                  } else {
                    result[`${c.name}Users`].push(u.id);
                  }
                } else if (columnName === "view") {
                  // if ((processingUsers.includes(u.id) || commandUsers.includes(u.id) || supportUsers.includes(u.id))) {

                  // } 
                  if (commandUsers.includes(u.id)) {
                    result["commandUsers"].push(u.id);
                  }
                  else if (processingUsers.includes(u.id)) {
                    result["processingUsers"].push(u.id);
                  }
                  else if (supportUsers.includes(u.id)) {
                    result["supportUsers"].push(u.id);
                  }
                  else {
                    result[`${c.name}Users`].push(u.id);
                  }
                } else {
                  result[`${c.name}Users`].push(u.id);
                }
                // if(`${c.name}Users`)
                if (c.name === 'command') {
                  getCommander && getCommander(u.roleGroupSource);
                }
                if (c.name === 'support') {
                  if (roleSupport.indexOf(u.roleGroupSource) === -1) {
                    roleSupport.push(u.roleGroupSource);
                  }
                  if (roleSupport.length > 0) {
                    let totalRole = roleSupport.reduce((str, i, index) => (str += index === roleSupport.length - 1 ? i : i + ','), '');
                    getSupportRole && getSupportRole(totalRole);
                  }
                }
              }
              if (c.name === 'processing' && u.data[c.name]) {
                if (rootTab === "receive" && processType === "any") {
                  // result[`${c.name}Users`] = [u.id];
                  getRole && getRole(u.roleGroupSource);
                } else {
                  result[`${c.name}Users`] = [u.id];
                  getRole && getRole(u.roleGroupSource);
                }

              }
            });
        });


        //  tích all đầu phòng

        if (listDepartmentsAcceps && Array.isArray(listDepartmentsAcceps) && listDepartmentsAcceps.length) {
          listDepartmentsAcceps.forEach(async (el) => {
            if (c.name === "support" && columnName === "support") {
              if (processing.includes(el)) {
                result[`${"processing"}`].push(el)
                // result =  await handleCheckDerpartmentAll(el, "processing", false)
              } else {
                if (!currentCheckAll) {
                  result[`${c.name}`].push(el)

                }
                result = await handleCheckDerpartmentAll(el, "support", currentCheckAll)

              }
            } else if (c.name === "view" && columnName === "view") {
              if (processing.includes(el)) {
                result[`${"processing"}`].push(el)
                // result = await  handleCheckDerpartmentAll(el, "processing", false)

              } else if (support.includes(el)) {
                result[`${"support"}`].push(el)
                // result = await handleCheckDerpartmentAll(el, "support", false)
              } else {
                if (!currentCheckAll) {
                  result[`${"view"}`].push(el)
                }
                result = await handleCheckDerpartmentAll(el, "view", currentCheckAll)
              }
            }
          })
        }




        if (onChangeColumnCheck) {
          onChangeColumnCheck(result, departments);
        }
      });
      setData(dataProcess)
      setReload(new Date() * 1)
      return;
    }
  };
  const handleCheckUserAllReceive = columnName => {
    if (columnSettings && columnSettings.length) {
      let newData = [...data];
      const listJoinOrganizationData = organizationData.map((it) => it._id)
      let listUser = [];
      if (columnName === 'processing') setCheckAll({ processing: !checkAll.processing });
      const newDataFilter = newData.filter((it) => !listJoinOrganizationData.includes(it.name))
      newData.map(el => {
        if (el.users && Array.isArray(el.users) && el.users.length > 0)
          el.users.map(user => {
            listUser.push(user);
          });
      });
      let derpartment = []
      let derpartmentCurrent = Array.isArray(data) && data.length > 0 && data[0].slug


      const result = { ...resultP };
      let user = []
      columnSettings.forEach(c => {
        result[c.name] = newData.filter(item => item.data[c.name]).map(item => item.name);
        result[`${c.name}Users`] = [];
        newDataFilter.map((el) => {
          if (checkAll[columnName] === true && el.slug.split('/').length === 1) derpartmentCurrent = el.slug
          if (checkAll[columnName] === true && el.slug.split('/').length === 2) el.data[c.name] = false
          else if (checkAll[columnName] === false && el.slug.split('/').length === 2) {
            el.data[c.name] = true
            derpartment.push(el.id)
          }
          else el.data[c.name] = false
        })
        const listJoin = listJoined.map((it) => it._id)
        // lọc người chỉ lấy ds người chưa tham gia
        listUser = listUser.filter((it) => !listJoin.includes(it._id))
        if (listUser && Array.isArray(listUser) && listUser.length > 0) {
          listUser.map(user => {
            // if (checkAll[columnName] === true) user.data[columnName] = false;
            // else user.data[columnName] = true;
            if (checkAll[columnName] === true && user["organizationUnit.organizationUnitId"] === derpartmentCurrent) user.data[columnName] = false
            else if (checkAll[columnName] === false && user["organizationUnit.organizationUnitId"] === derpartmentCurrent) user.data[columnName] = true
            else user.data[c.name] = false
          });
        }
        newData.forEach(rowData => {
          rowData.users &&
            rowData.users.forEach(u => {
              if (c.name === 'processing' && u.data[c.name] && derpartmentCurrent === u['organizationUnit.organizationUnitId']) {
                // result[`${c.name}Users`] = [u._id];
                user.push(u._id)
                getRole && getRole(u.roleGroupSource);
              }
            });
        });
        result[`${c.name}Users`] = user


        result[`${c.name}`] = derpartment
        if (onChangeColumnCheck) {
          onChangeColumnCheck(result, departments);
        }
      });
      return;
    }
  };
  function expandRow(slug, name, expand) {
    let tabDerpartment;

    if (expand) {
      tabDerpartment = departments.map(i => {
        if (i.name === name) return { ...i, expand: false };
        if (i.slug.includes(slug)) return { ...i, open: false, hide: true };
        return i;
      });
    } else {
      tabDerpartment = departments.map(i => {
        if (i.name === name) return { ...i, expand: true };
        if (i.parent === name) return { ...i, open: true, hide: false };
        return i;
      });
    }
    setDepartments(tabDerpartment);
  }
  return (
    <>
      <div style={{ marginTop: '20px' }}>
        <p>{title}</p>
      </div>
      <div style={{ width: 200, marginBottom: 10, marginTop: -25 }}>
        <TextFieldUI
          variant="outlined"
          InputProps={{
            startAdornment: <Search />,
          }}
          placeholder="Tìm kiếm..."
          ref={input => (this.search = input)}
          onChange={handleSearch}
        // value={search}
        />
      </div>
      <div style={{ padding: '0 10px', height: 'calc(100vh - 370px)', overflow: 'scroll' }}>
        <Grid container style={{ justifyContent: 'space-between', marginBottom: 5, paddingRight: 10 }}>
          <Grid item xs={6}>
            Tên đơn vị, cá nhân
          </Grid>
          {columns.filter((i => hasOneColumn ? i.name === "processing" : i)).map(i => (
            <>
              {
                <Grid item style={{ textAlign: 'center', maxWidth: i.title === "Xử lý chính" && rootTab === "receive" && processType === "any" ? '150px' : "90px", width: i.title === "Xử lý chính" && rootTab === "receive" && processType === "any" ? '150px' : "90px", fontSize: 13, fontWeight: "bold" }}>

                  <>
                    {
                      // !i.isColumnVirtual && (
                      <>
                        {i.title === "Xử lý chính" && rootTab === "receive" && processType === "any" ? "Chọn đơn vị/cá nhân" : i.title}
                      </>
                      // ) || null
                    }
                  </>
                </Grid> || null
              }
            </>
          ))}
        </Grid>

        <div style={{ height: 'calc(100vh - 405px)', overflowY: 'scroll', paddingBottom: 20 }}>
          {departments.map(
            (i, rowIndex) =>
              !rowIndex || i.open && ((countObj[i._id] > 0) && (i.child || (data[rowIndex] && data[rowIndex].users && data[rowIndex].users.length > 0)) || (processType === 'any' && allowSendToUnit && organizationUnit !== i._id)) ? (
                <>

                  <Grid
                    className='customHover'
                    container
                    style={{ justifyContent: 'space-between', borderBottom: '1px solid #e2e2e2', display: 'flex', alignItems: 'center' }}
                  >

                    {((rowIndex === 0 && roleP === 'processors' && Array.isArray(data) && data.length) ||
                      (rowIndex === 0 && roleP === 'commander' && Array.isArray(data) && data.length)) && Array.isArray(columns) && columns.length == 4 && (
                        <>
                          <Grid item xs={6} md={6} xl={6} style={props.firstColumnStyle || styles.codeCol}>
                          </Grid>
                          <Grid container xs={6} md={6} xl={6} style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                            <Grid item xs={6} md={6} xl={6} />
                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {columns && columns[0] && columns[0].name === 'processing' && columns && Array.isArray(columns) && columns.length === 4 ? null : (
                                <>
                                  {
                                    columns && columns[2] && columns[2].name === 'support' && !columns[2].isColumnVirtual && <Checkbox
                                      onChange={() => {
                                        handleCheckUserAll('support');
                                      }}
                                      checked={checkAll.support || false}
                                    />
                                  }
                                  {/* <Checkbox
                                    onChange={() => {
                                      handleCheckUserAll('support');
                                    }}
                                    checked={checkAll.support || false}
                                  /> */}
                                </>
                              )}
                            </Grid>

                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {/* <Checkbox
                                onChange={() => {
                                  handleCheckUserAll('view');
                                }}
                                checked={checkAll.view || false}
                              /> */}
                              {
                                columns && columns[3] && columns[3].name === 'view' && !columns[3].isColumnVirtual && <Checkbox
                                  onChange={() => {
                                    handleCheckUserAll('view');
                                  }}
                                  checked={checkAll.view || false}
                                />
                              }
                            </Grid>
                          </Grid>
                        </>

                      )}


                    {((rowIndex === 0 && roleP === 'processors' && Array.isArray(data) && data.length) ||
                      (rowIndex === 0 && roleP === 'commander' && Array.isArray(data) && data.length)) && Array.isArray(columns) && columns.length == 3 && (
                        <>
                          <Grid item xs={4} md={4} xl={4} style={props.firstColumnStyle || styles.codeCol}>
                          </Grid>
                          <Grid container xs={8} md={8} xl={8} style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                            <Grid item xs={6} md={6} xl={6} />
                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {columns && columns[0] && columns[0].name === 'processing' && columns && Array.isArray(columns) && columns.length === 4 ? null : (
                                // <Checkbox
                                //   onChange={() => {
                                //     handleCheckUserAll('support');
                                //   }}
                                //   checked={checkAll.support || false}
                                // />
                                <>
                                  {
                                    columns && columns[2] && columns[2].name === 'support' && !columns[2].isColumnVirtual && <Checkbox
                                      onChange={() => {
                                        handleCheckUserAll('support');
                                      }}
                                      checked={checkAll.support || false}
                                    />
                                  }
                                </>
                              )}
                            </Grid>

                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {/* <Checkbox
                                onChange={() => {
                                  handleCheckUserAll('view');
                                }}
                                checked={checkAll.view || false}
                              /> */}
                              <>
                                {
                                  columns && columns[3] && columns[3].name === 'view' && !columns[3].isColumnVirtual && <Checkbox
                                    onChange={() => {
                                      handleCheckUserAll('view');
                                    }}
                                    checked={checkAll.view || false}
                                  />
                                }
                              </>
                            </Grid>
                          </Grid>
                        </>

                      )}
                    {
                      (
                        // (rowIndex === 0 && roleP === 'processors' && Array.isArray(data) && data.length) ||
                        (rowIndex === 0 && roleP === 'supporters' && Array.isArray(data) && data.length)) && Array.isArray(columns) && columns.length == 4 && (
                        <>
                          <Grid item xs={6} md={6} xl={6} style={props.firstColumnStyle || styles.codeCol}>
                          </Grid>
                          <Grid container xs={6} md={6} xl={6} style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                            <Grid item xs={6} md={6} xl={6} />
                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {columns && columns[0] && columns[0].name === 'processing' && columns && Array.isArray(columns) && columns.length === 4 ? null : (
                                // <Checkbox
                                //   onChange={() => {
                                //     handleCheckUserAll('support');
                                //   }}
                                //   checked={checkAll.support || false}
                                // />
                                <>
                                  {
                                    columns && columns[2] && columns[2].name === 'support' && !columns[2].isColumnVirtual && <Checkbox
                                      onChange={() => {
                                        handleCheckUserAll('support');
                                      }}
                                      checked={checkAll.support || false}
                                    />
                                  }
                                </>
                              )}
                            </Grid>

                            <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              {/* <Checkbox
                                onChange={() => {
                                  handleCheckUserAll('view');
                                }}
                                checked={checkAll.view || false}
                              /> */}
                              <>
                                {
                                  columns && columns[3] && columns[3].name === 'view' && !columns[3].isColumnVirtual && <Checkbox
                                    onChange={() => {
                                      handleCheckUserAll('view');
                                    }}
                                    checked={checkAll.view || false}
                                  />
                                }
                              </>
                            </Grid>
                          </Grid>
                        </>

                      )}

                    {(rowIndex === 0 && roleP === 'receive' && processType === "any" && Array.isArray(data) && data.length) && Array.isArray(columns) && columns.length == 4 && (
                      <>
                        <Grid item xs={6} md={6} xl={6} style={props.firstColumnStyle || styles.codeCol}>
                        </Grid>
                        <Grid container xs={6} md={6} xl={6} style={{ justifyContent: 'space-between', alignItems: 'center' }}>
                          <Grid item xs={3} md={3} xl={3} />
                          <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>

                          </Grid>
                          <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>

                          </Grid>
                          <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>

                            <>
                              {
                                columns && columns[1] && columns[1].name === 'processing' && !columns[1].isColumnVirtual && <Checkbox
                                  onChange={() => {
                                    handleCheckUserAllReceive('processing');
                                  }}
                                  checked={checkAll.processing || false}
                                />
                              }
                            </>
                          </Grid>

                        </Grid>
                      </>

                    )}
                    <Grid item xs={6} md={6} xl={6} style={props.firstColumnStyle || styles.codeCol} >
                      <p
                        style={{ padding: 5, paddingLeft: i.level ? i.level * 10 : 0, fontWeight: i.child ? 'bold' : false, margin: 0 }}
                        onClick={e => {
                          e.stopPropagation();
                          expandRow(i.slug, i.name, i.expand);
                        }}
                      >
                        <AccountBalance style={{ paddingRight: 10 }} />
                        {i.title}
                        {i.child || (data[rowIndex] && data[rowIndex].users && data[rowIndex].users.length > 0) ? (
                          i.expand ? (
                            <>
                              <ExpandLess />
                            </>
                          ) : (
                            <ExpandMore />
                          )
                        ) : null}
                      </p>
                    </Grid>
                    {
                      console.log(organizationData, "organizationData", listJoined)
                    }
                    {columns.filter((i => hasOneColumn ? i.name === "processing" : i)).map(it => (
                      <Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }} >
                        {
                          // !it.isColumnVirtual &&
                          ((processType === 'any' && allowSendToUnit && organizationUnit !== i._id && it.name !== "command") || (processType !== 'any' && role.processing_free_role_to_set && it.allowSelectDepartment && data[rowIndex] && data[rowIndex].allowedSelectDepartment)) ? (
                            <>

                              {(processType === 'any' && rootTab === "receive" && organizationParent === i._id) ? null :
                                <>
                                  <CheckDerpartment
                                    isView={
                                      // đơn vị đã tham gia xử lý
                                      // !(i.level <= 1) ? true : ( // chỉ chuyển đầu đơn vị lệch 1 cấp
                                      it.isColumnVirtual ||
                                        organizationData.find((item) => item._id == i.id && item.checkHidden && (
                                          item.checkHidden.command ||
                                          item.checkHidden.processing ||
                                          item.checkHidden.support ||
                                          item.checkHidden.view)) ? true : false ||
                                            props.isView ? props.isView : null
                                      // )
                                    }
                                    handleCheckDerpartment={handleCheckDerpartment}
                                    checked={

                                      // đơn vị đã tham gia xử lý với vai trò cùng với cột
                                      organizationData.find((item) => item._id == i.id && item.checkHidden && item.checkHidden[it.name]) ? true : false ||
                                        data[rowIndex] && data[rowIndex].data && data[rowIndex].data[it.name] ? true : false
                                    }
                                    column={it.name}
                                    roleP={roleP}
                                    processType={processType}
                                    row={i.name}
                                  />
                                </>
                              }
                            </>
                          ) : null}
                      </Grid>
                    ))}
                  </Grid>
                  {i.expand && data[rowIndex] && data[rowIndex].users && data[rowIndex].users.length
                    ? sortAZ(data[rowIndex].users).map(user => (
                      <>
                        <Grid container className='customHover' style={{ justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e2e2' }}>
                          <Grid item xs={6} style={props.firstColumnStyle || styles.codeCol}>
                            <p
                              style={{
                                paddingLeft: i.level ? (i.level + 1) * 10 : 0,
                                color: '#2196F3',
                                margin: 0,
                                minHeight: 40,
                                display: 'flex',
                                alignItems: 'center',
                              }}
                            >
                              <AccountCircle style={{ paddingRight: 10 }} />
                              {user.userName}
                            </p>
                          </Grid>

                          {columns.filter((i => hasOneColumn ? i.name === "processing" : i)).map(it => (

                            <Grid Grid item style={{ display: 'flex', justifyContent: 'center', maxWidth: '100px', width: '100px' }}>
                              <>
                                {
                                  // !it.isColumnVirtual &&
                                  (
                                    <>
                                      {roleP === 'supporters' ? (
                                        <Checkbox
                                          onChange={() => {
                                            handleCheckUser(user.id, it.name, rowIndex, user);
                                          }}
                                          disabled={(listJoined.find(item => item._id === user.id)) ||
                                            organizationData.find((it) => user.organizationUnit && it._id === user.organizationUnit.organizationUnitId && it.checkHidden && (
                                              // it["checkHidden.command"] ||
                                              // it["checkHidden.processsing"] ||
                                              // it["checkHidden.support"] ||
                                              // it["checkHidden.view"]
                                              it.checkHidden.command ||
                                              it.checkHidden.processing ||
                                              it.checkHidden.support ||
                                              it.checkHidden.view
                                            ))// đã xử lý rồi thì disable đi hoặc phòng đã xử lý
                                            || it.isColumnVirtual // cột ảo thì cũng disable đi
                                          }
                                          // item[`checkHidden.${it.name}`]))
                                          checked={(user && user.data && user.data[it.name]) ||
                                            (listJoined.find(item => item._id === user.id && item.checkHidden && item.checkHidden[it.name])) ||
                                            false}
                                        />
                                      ) : (
                                        <>

                                          {!user[`roleCached.IncommingDocument.${it.name}_view`] ||
                                            it.name === 'commander' ||
                                            (it.name === 'processing' && user.disableSetProcess) ? null : (
                                            <>

                                              <Checkbox
                                                onChange={() => {
                                                  handleCheckUser(user.id, it.name, rowIndex, user);
                                                }}
                                                disabled={
                                                  listJoined.find(item => item._id === user.id && item[`checkHidden.${it.name}`]) || // người đã tham gia xử lý
                                                  listJoined.find(item => item._id === user.id && ( // đơn vị tham gia xử lý
                                                    item["checkHidden.command"] ||
                                                    item["checkHidden.processing"] ||
                                                    item["checkHidden.support"] ||
                                                    item["checkHidden.view"]
                                                  )) || // đã tham gia xử lý
                                                  it.isColumnVirtual || // cột ảo thì cũng disable đi
                                                  listJoined.find((item => item[`checkHidden.${it.name}`])) && (it.name === "command" || it.name === "processing") && (!(rootTab === "receive" && processType === "any")) || // người cùng đơn vị tham gia xử lý
                                                  organizationData.find((it) => user.organizationUnit && it._id === user.organizationUnit.organizationUnitId && it.checkHidden && ( // đơn vị tham gia xử lý
                                                    it.checkHidden.command ||
                                                    it.checkHidden.processing ||
                                                    it.checkHidden.support ||
                                                    it.checkHidden.view
                                                  )) && (!(rootTab === "receive" && processType === "any")) ||
                                                  organizationData.find((it) => user.organizationUnit && it._id === user.organizationUnit.organizationUnitId && it.checkHidden && ( // đơn vị tham gia xử lý
                                                    it.checkHidden[it.name]
                                                  )) && (!(rootTab === "receive" && processType === "any"))
                                                } // đã xử lý rồi thì disable đi hoặc đã có ng xl rồi( xlc - cđ)
                                                checked={
                                                  (listJoined.find(item => item._id === user.id && item[`checkHidden.${it.name}`])) || (user && user.data && user.data[it.name])
                                                  || false}
                                              />
                                            </>
                                          )}
                                          {type === '' ||
                                            type === 'flow' ||
                                            (!user[`roleCached.IncommingDocument.${it.name}_view`] || it.name === 'commanders') ||
                                            (it.name === 'processing' && !user.disableSetProcess) ? null : (
                                            <>
                                              <Checkbox
                                                onChange={() => {
                                                  handleCheckUser(user.id, it.name, rowIndex, user);
                                                }}
                                                disabled={
                                                  it.isColumnVirtual  // cột ảo thì cũng disable đi
                                                }
                                                checked={(user && user.data && user.data[it.name]) || false}
                                              />
                                            </>
                                          )}
                                          {type !== '' &&
                                            type === 'flow' && (
                                              <>
                                                <Checkbox
                                                  onChange={() => {
                                                    handleCheckUser(user.id, it.name, rowIndex, user);
                                                  }}
                                                  disabled={
                                                    it.isColumnVirtual  // cột ảo thì cũng disable đi
                                                  }
                                                  checked={(user && user.data && user.data[it.name]) || false}
                                                />
                                              </>
                                            )}
                                          {type !== '' &&
                                            type !== 'flow' && (
                                              <Checkbox
                                                onChange={() => {
                                                  handleCheckUser(user.id, it.name, rowIndex, user);
                                                }}
                                                disabled={
                                                  it.isColumnVirtual  // cột ảo thì cũng disable đi
                                                }
                                                checked={(user && user.data && user.data[it.name]) || false}
                                              />
                                            )}
                                        </>
                                      )}
                                    </>
                                  ) || null
                                }
                              </>

                            </Grid>
                          ))}
                        </Grid>
                      </>
                    ))
                    : null}
                </>
              ) : null,
          )}
        </div>
      </div>
    </>
  );
}

function CheckDerpartment({ handleCheckDerpartment, row, column, checked, isView, roleP, processType }) {
  function check() {
    // row: id phòng ban
    // column: name column
    // checked: status check
    handleCheckDerpartment(row, column, checked);
  }
  // An hien o day
  return processType === 'flow' || (processType !== 'any' && roleP == 'commander') ? null : (
    <Checkbox disabled={isView} onClick={check} checked={checked} />
  );
}

DepartmentSelect.propTypes = {};

export default DepartmentSelect;

const styles = {
  codeCol: {
    minWidth: '34vw',
  },
};
