// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import ExportStockDialog from '../index';

describe('<ExportStockDialog />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
