// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import LifetekUi from '../index';

describe('<LifetekUi />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
