const styles = () => ({
  border: {
    borderLeft: '1px solid #000',
    borderRight: '1px solid #000',
  },
});
export default styles;
