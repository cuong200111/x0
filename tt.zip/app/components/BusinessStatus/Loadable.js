/**
 *
 * Asynchronously loads the component for BusinessStatus
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
