import React, { useState, useCallback, useEffect } from 'react';
import { Button, Grid, Table, TableRow, Typography } from '@material-ui/core';
import moment from 'moment';
import { Dialog as DialogUI } from 'components/LifetekUi';
import CustomDatePicker from '../CustomDatePicker/CustomDatePickerCustom';
import { serialize } from '../../utils/common';
import request from '../../utils/request';
import { API_INCOMMING_DOCUMENT_CHANGE_DEADLINE, API_INCOMMING_DOCUMENT_SET_DEADLINE, API_USERS } from '../../config/urlConfig';
import CustomInputBase from '../Input/CustomInputBase';
import { AsyncAutocomplete } from '../LifetekUi';
import { TableCell, TableHead } from '@mui/material';
import { fetchData } from '../../helper';

function ExtendHanleDialog(props) {
  const { onClose, onChangeSnackbar, item, onSuccess } = props;
  const [localState, setLocalState] = useState({
    loading: false
  });
  const handleInputChange = (e, _name, _value) => {
    setLocalState({ ...localState, [_name]: _value });
  };

  const onSave = async () => {
    try {
      // if (!localState.newDeadline && !moment(localState.newDeadline).isAfter(moment())) {
      //   onChangeSnackbar({ status: true, message: 'Ngày gia hạn phải sau ngày hiện tại!', variant: 'error' });
      //   return;
      // }
      const {listExtend} = localState;
      const foundError = listExtend.find(it=> !it.deadline);
      if(foundError) return onChangeSnackbar({ status: true, message: 'Hạn xử lý chưa được nhập đầy đủ, đồng chí vui lòng kiểm tra lại!', variant: 'error' });
      let flag = true
      for (let i = 0; i < listExtend.length; i++) {
        if(listExtend[i] && listExtend[i].oldDeadline){
          const current = moment(listExtend[i].oldDeadline, "DD/MM/YYYY").startOf("date")
          const now = moment(listExtend[i].deadline).startOf("date")
          flag = now && (new Date(current) * 1 && (new Date(current) * 1  < new Date(now) * 1)) ;
          if(flag) break;
        }
      }
      let confirmDialog = true
      if(flag){
        confirmDialog = confirm("Hạn lớn hơn hạn xử lý của cấp trên giao, đồng chí có muốn gia hạn không?")
      }
      if(confirmDialog){
      const body = {
        docId: [item._id],
        userDeadlines: listExtend.map((el)=>{
          return{
            userId : el._id,
            stepDeadline : moment(el.deadline).format("DD/MM/YYYY")
          }
        })
      }
      setLocalState({...localState, loading: true})

      const res = await fetchData(`${API_INCOMMING_DOCUMENT_CHANGE_DEADLINE}`, 'POST', body)
      
      setLocalState({...localState, loading: false})

      // {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      //   body: JSON.stringify({
      //     docIds: [item && item.originItem && item.originItem._id],
      //     deadline: localState.newDeadline,
      //   }),
      // }
      // );
      if (res && res.status) {
        onChangeSnackbar({ status: true, message: 'Đặt hạn xử lý thành công', variant: 'success' });
        if (onSuccess) {
          onSuccess();
        }
      }
      if (onClose) {
        onClose();
      }
    }
    } catch (error) {
      onChangeSnackbar({ status: true, message: res.message || error.message, variant: 'error' });
      setLocalState({...localState, loading: false})

    }
  };

  // useEffect(
  //   () => {
  //     const minDate =
  //       item.originItem && item.originItem.deadline && moment(item.originItem.deadline).isAfter(moment())
  //         ? moment(item.originItem.deadline).add(1, 'day')
  //         : moment().add(1, 'day');
  //     setLocalState({ ...localState, newDeadline: minDate });
  //   },
  //   [item.originItem],
  // );

  const minDate =
    item.originItem && item.originItem.deadline && moment(item.originItem.deadline).isAfter(moment())
      ? moment(item.originItem.deadline).add(1, 'day')
      : moment().add(1, 'day');
  const { originItem = {} } = item
  const { processors = [], commander = [], supporters = [], viewers = [] } = originItem
  const listprocess = [...processors, ...commander, ...supporters].filter(it => it)
  const filter = { _id: { $in: listprocess } };
  const query = serialize({ filter });
  const { listPersonal = [] , listExtend =[], loading} = localState
  return (
    <div>
      <Typography variant="h6" component="h2" gutterBottom display="block" style={{ textTransform: 'uppercase' }} align="center">
        Đặt hạn xử lý
      </Typography>
      <Grid container spacing={8}>
        <Grid item xs="12" spacing={24} style={{ padding: '0 30px' }}>
          {
            listprocess && listprocess.length ? <AsyncAutocomplete
              isMulti
              onChange={value => {
                const {listExtend = []} = localState
                const {originItem = {}} = item
                const { userDeadline = []} = originItem
                const newValue = value ? value.map(el=>{
                  const found = listExtend.find(it=>it._id === el._id);
                  return {
                    _id: el._id, 
                    name: el.name,
                    deadline: found && found.deadline || null,
                    oldDeadline: userDeadline[el._id]  &&( userDeadline[el._id].length === 10 ? moment(userDeadline[el._id], "DD/MM/YYYY").format('DD/MM/YYYY') :  moment(userDeadline[el._id]).format("DD/MM/YYYY") )|| null
                  }
                }
                ) : []
                setLocalState({ ...localState, listPersonal: value || [] , listExtend: newValue})
              }}
              label="Gia hạn cho"
              // value={action.additionData.toNotice}
              url={`${API_USERS}?${query}`}
            /> : null
          }

        </Grid>
        {/* <Grid item xs="12" spacing={24} style={{ padding: '0 30px' }}>
          <CustomInputBase
            value={item.originItem && item.originItem.deadline ? moment(item.originItem.deadline).format('DD/MM/YYYY') : null}
            disabled
            label="Thời gian hiện tại"
          />
        </Grid> */}
        
        <Grid item xs="12" spacing={24} style={{ padding: '0 30px' }}>
          <CustomDatePicker
            label="Ngày gia hạn"
            value={localState.newDeadline || null}
            name="newDeadline"
            type="date-time"
            format="DD/MM/YYYY"
            minDate={moment()}
            onChange={e =>{
              handleInputChange(e, 'newDeadline', e)
              let {listExtend = []} = localState
              listExtend = listExtend.map((el)=>{
                return {
                  ...el,
                  deadline: e
                }
              })
              setLocalState({...localState, listExtend,newDeadline : e })
              
            }}
            autoFocus
          />
        </Grid>
        <Grid item xs="12" spacing={24} style={{ padding: '0 30px' , maxHeight: 450, overflow: "auto"}}>
          <Table>
            <TableHead>
              <TableCell>
                Cán bộ
              </TableCell>
              <TableCell>
                Thời gian hiện tại
              </TableCell>
              <TableCell>
                Ngày gia hạn
              </TableCell>
            </TableHead>

            {
              listExtend.map((el, idx) => {
                return (<>
                  <TableRow>
                    <TableCell>
                      {el.name}
                    </TableCell>
                    <TableCell>
                      {el.oldDeadline}
                    </TableCell>
                    <TableCell>

                      <CustomDatePicker
                        label=""
                        value={el.deadline || null}
                        name="deadline"
                        required
                        type="date-time"
                        format="DD/MM/YYYY"
                        minDate={moment()}
                        onChange={e => {
                          let {listExtend = [] } = localState;
                          listExtend = listExtend.map((el, index)=>{
                            if(idx !== index) return el
                            return {
                              ...el,
                              deadline: e
                            }
                          })
                          setLocalState({...localState, listExtend})
                        }}
                        autoFocus
                      />
                    </TableCell>
                  </TableRow>
                </>)
              })
            }
          </Table>
        </Grid>
      </Grid>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 20, paddingRight: 30 }}>
        <Button onClick={onSave} color="primary" variant="contained" disabled={!(listExtend && listExtend.length) || loading}>
          Gia hạn
        </Button>
      </div>
    </div>
  );
}

export default ExtendHanleDialog;
